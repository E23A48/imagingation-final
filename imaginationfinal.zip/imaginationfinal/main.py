import enum
from typing import List
from starlette.responses import StreamingResponse
from fastapi import FastAPI
from pydantic import BaseModel
from modules.preprocessing import preprocessStory
from modules.image_retrieval import imageRetrievalBing
from fastapi.middleware.cors import CORSMiddleware
# from pdfCreator import createPDF
from starlette.responses import FileResponse
from modules.semantic_match import sentenceSimilarity
import requests


app = FastAPI()

origins = ['*']

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Payload(BaseModel):
    story: str
    

@app.get("/")
async def root():
    return {"message": "Hello World"}

def downloadImages(url_images):
    for idx,image_url in enumerate(url_images):
        img_data = requests.get(image_url).content
        with open(f'image_name_{idx}.jpg', 'wb') as handler:
            handler.write(img_data)

@app.post("/imagination")
async def root(payload: Payload):
    # modulo 1 
    response_en, response_es, processed_sentences = preprocessStory(payload.story)
    # modulo 2 

    # modulo 3

    # modulo 4

    url_images = imageRetrievalBing([x.text for x in response_en])
    
    # modulo 5
    # downloadImages(url_images) para descargar las imagenes localmente
    # sentenceSimilarity(processed_sentences,
    # [
    #     [{"imageUrl": 'test' , 'caption':'test caption' },
    #    {"imageUrl": 'test2' , 'caption':'hello' }, ] , 

    #     [{"imageUrl": 'test_2' , 'caption':'not walking' },
    #    {"imageUrl": 'test2_2' , 'caption':'test caption2_2' }, ] , 

    # ])


    return {"result": {
        "original_story": [x.capitalize() for x in response_es], 
         "english_story": [x.text.capitalize() for x in response_en], 
         "proccessed_sentences": processed_sentences,
          "url_images": url_images
          }}

# class Payload2(BaseModel):
#     sentences:list = []
#     images:list = []



# @app.post("/createPDF")
# async def root(payload: Payload2):
#     pdfName = createPDF(payload.images,payload.sentences)
#     return FileResponse(pdfName, media_type='application/octet-stream',filename="file_name.pdf")
