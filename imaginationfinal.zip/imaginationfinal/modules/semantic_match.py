import math
import re
from collections import Counter

def get_cosine(vec1, vec2):
    intersection = set(vec1.keys()) & set(vec2.keys())
    # print(intersection)
    numerator = sum([vec1[x] * vec2[x] for x in intersection])

    sum1 = sum([vec1[x] ** 2 for x in list(vec1.keys())])
    sum2 = sum([vec2[x] ** 2 for x in list(vec2.keys())])
    denominator = math.sqrt(sum1) * math.sqrt(sum2)

    if not denominator:
        return 0.0
    else:
        return float(numerator) / denominator

WORD = re.compile(r"\w+")
def text_to_vector(text):
    words = WORD.findall(text)
    return Counter(words)


def sentenceSimilarity(original_sentences, captions):
    results = []

    for idx in range(len(original_sentences)):
        sentence = original_sentences[idx]
        vector_sentence = text_to_vector(sentence.lower())
        current_image_captions = captions[idx]
        temp = {
            'sentence':'',
            'rating':-1
        }

        for curr in current_image_captions:
            sen = text_to_vector(curr['caption'].lower())
           
            if get_cosine(vector_sentence, sen) > temp['rating']:
                temp = {
                    'sentence':curr['caption'].lower(),
                    'rating':round(get_cosine(vector_sentence, sen),3)}
        
        results.append(temp)


            
    print(results)
    return results
    