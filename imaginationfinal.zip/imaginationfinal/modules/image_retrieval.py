import requests
from serpapi import GoogleSearch

def imageRetrievalBing(keywords):
    url_images = []
    for x in keywords:
        params = {
          "engine": "google",
          "tbm": "isch",
          "q": x,
          "api_key": 
          "7165d94c51c51332d88e7284e91a11cf690a5e8a0a7d3eb7052f542d0fc4c789"
          
        }

        search = GoogleSearch(params)
        results = search.get_dict()
        organic_results = results['images_results']
        print(len(organic_results))
        thumbnails_result_top = [q['thumbnail'] for q in organic_results[:16]][0]

        url_images.append(thumbnails_result_top)
        
    return url_images
