#@title Imports

#importamos librerias necesarias
import clip
# import os
# from torch import nn
# import numpy as np
# import torch
# import torch.nn.functional as nnf

# # import sys
# from typing import Tuple, List, Union, Optional

# from transformers import GPT2Tokenizer, GPT2LMHeadModel, AdamW, get_linear_schedule_with_warmup

# from tqdm import tqdm, trange #not

# from google.colab import files

# import skimage.io as io
# import PIL.Image
# from IPython.display import Image 

def do():
    print('adsf')
    # #creando variables necesarias
    # N = type(None)
    # V = np.array
    # ARRAY = np.ndarray
    # ARRAYS = Union[Tuple[ARRAY, ...], List[ARRAY]]
    # VS = Union[Tuple[V, ...], List[V]]
    # VN = Union[V, N]
    # VNS = Union[VS, N]
    # T = torch.Tensor
    # TS = Union[Tuple[T, ...], List[T]]
    # TN = Optional[T]
    # TNS = Union[Tuple[TN, ...], List[TN]]
    # TSN = Optional[TS]
    # TA = Union[T, ARRAY]


    # #creando objeto de pytorch
    # D = torch.device
    # #estableciendo que pytorch usara CPU
    # CPU = torch.device('cpu')


    # def get_device(device_id: int) -> D:
    #     if not torch.cuda.is_available():
    #         return CPU
    #     device_id = min(torch.cuda.device_count() - 1, device_id)
    #     return torch.device(f'cuda:{device_id}')


    # CUDA = get_device

    # current_directory = os.getcwd()
    # print(current_directory)
    # save_path = os.path.join(os.path.dirname(current_directory), "pretrained_models")
    # print(save_path)
    # os.makedirs(save_path, exist_ok=True)
    # model_path = os.path.join(save_path, 'model_wieghts.pt')
    # print(model_path)