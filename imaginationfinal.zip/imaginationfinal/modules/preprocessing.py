import re
import unidecode 
from googletrans import Translator


def translateStory(story):
  translator = Translator()
  return translator.translate(story, src="es")

def separateSentences(story):
  sentences = story.split('.')

  if(sentences[-1] == ""):

    return sentences[:-1]

  return sentences

def preprocessStory(story):
  # stpw = stopwords.words('english')
  payload = separateSentences(story)

  print('payload',payload)

  translatedStory = translateStory(payload)

  # separated_sentences = separateSentences(translatedStory)
  separated_sentences = translatedStory
  processed_sentences = []
  for sentence in separated_sentences:
    sentence = sentence.text
    #eliminando masyusculas
    X = sentence.lower()
    #sacar acentos
    X = unidecode.unidecode(X)
    #Sin caracteres especiales
    X= re.sub(u'[^a-zA-ZáéíóúÁÉÍÓÚâêîôÂÊÎÔãõÃÕçÇñ@# ]', '', X) 
    #Arreglo espacios innecesarios
    X = re.sub(' +', ' ', X)
    # #sacar stopwords
    # X= " ".join([word for word in X.split() if word.lower() not in stpw])

    processed_sentences.append(X)

  return separated_sentences, separateSentences(story), processed_sentences